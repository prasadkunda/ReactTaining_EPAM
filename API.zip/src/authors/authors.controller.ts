import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  UseGuards,
} from '@nestjs/common';
import { ApiBasicAuth, ApiBody, ApiHeader, ApiResponse, ApiTags } from '@nestjs/swagger';

import { Observable } from 'rxjs';

import {
  FailedRequest,
  ItemModel,
  SuccessfulRequest,
} from '@models/common.models';

import { Authorized, Roles } from '@helpers/decorators';

import { AuthorizationGuard } from '@core/authorization.guard';
import { METADATA_AUTHORIZED_KEY, UserRoles } from '@core/core-module.config';
import { RoleGuard } from '@core/role.guard';
import { SwaggerAuthor, SwaggerAuthorDeleteResponse, SwaggerAuthorResponse, SwaggerAuthorsResponse } from '@swagger/models';

import { AuthorModel } from './authors.models';
import { AuthorsService } from './authors.service';

@Controller('authors')
@ApiTags('Authors')
@UseGuards(AuthorizationGuard, RoleGuard)
export class AuthorsController {
  constructor(private authorsService: AuthorsService) {}

  @Get('all')
  @ApiResponse({
    status: 200,
    description: 'Get all authors',
    type: SwaggerAuthorsResponse,
  })
  getAllAuthors(): Observable<
    SuccessfulRequest<ItemModel[] | string> | FailedRequest
  > {
    return this.authorsService.getAllAuthors();
  }

  @Post('add')
  @ApiHeader({
    name: METADATA_AUTHORIZED_KEY,
    description: 'Authorization token "Bearer {token}"',
  })
  @ApiBody({
    type: SwaggerAuthor,
  })
  @ApiResponse({
    status: 200,
    description: 'Create a new author',
    type: SwaggerAuthorResponse,
  })
  @ApiBasicAuth(METADATA_AUTHORIZED_KEY)
  @Authorized()
  @Roles(UserRoles.admin)
  addAuthor(
    @Body() body: AuthorModel,
  ): Observable<SuccessfulRequest<string | ItemModel> | FailedRequest> {
    return this.authorsService.addAuthor(body);
  }

  @Get(':id')
  @ApiResponse({
    status: 200,
    description: 'Get single author by ID',
    type: SwaggerAuthorResponse,
  })
  getSingleAuthor(
    @Param('id') id: string,
  ): Observable<SuccessfulRequest<ItemModel | string> | FailedRequest> {
    return this.authorsService.getAuthor(id);
  }

  @Put(':id')
  @ApiHeader({
    name: METADATA_AUTHORIZED_KEY,
    description: 'Authorization token "Bearer {token}"',
  })
  @ApiBody({
    type: SwaggerAuthor,
  })
  @ApiResponse({
    status: 200,
    description: 'Get single author by ID',
    type: SwaggerAuthorResponse,
  })
  @ApiBasicAuth(METADATA_AUTHORIZED_KEY)
  @Authorized()
  @Roles(UserRoles.admin)
  editAuthor(
    @Param('id') id: string,
    @Body() body: AuthorModel,
  ): Observable<SuccessfulRequest<string> | FailedRequest> {
    return this.authorsService.editAuthor(body, id);
  }

  @Delete(':id')
  @ApiHeader({
    name: METADATA_AUTHORIZED_KEY,
    description: 'Authorization token "Bearer {token}"',
  })
  @ApiResponse({
    status: 200,
    description: 'Delete author by ID',
    type: SwaggerAuthorDeleteResponse,
  })
  @ApiBasicAuth(METADATA_AUTHORIZED_KEY)
  @Authorized()
  @Roles(UserRoles.admin)
  deleteAuthor(
    @Param('id') id: string,
  ): Observable<SuccessfulRequest<string> | FailedRequest> {
    return this.authorsService.deleteAuthor(id);
  }
}
