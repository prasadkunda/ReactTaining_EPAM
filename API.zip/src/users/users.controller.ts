import { Controller, Get, Request, UseGuards } from '@nestjs/common';
import { ApiBasicAuth, ApiHeader, ApiResponse, ApiTags } from '@nestjs/swagger';

import { SuccessfulRequest } from '@models/common.models';

import { Authorized } from '@helpers/decorators';

import { User } from '@auth/auth.models';
import { AuthorizationGuard } from '@core/authorization.guard';
import { METADATA_AUTHORIZED_KEY } from '@core/core-module.config';
import { SwaggerUserResponse } from '@swagger/models';

@Controller('users')
@ApiTags('Users')
@UseGuards(AuthorizationGuard)
export class UsersController {
  @ApiHeader({
    name: METADATA_AUTHORIZED_KEY,
    description: 'Authorization token "Bearer {token}"',
  })
  @ApiResponse({
    status: 200,
    description: 'Get current user',
    type: SwaggerUserResponse,
  })
  @Get('me')
  @ApiBasicAuth(METADATA_AUTHORIZED_KEY)
  @Authorized()
  getUser(@Request() req: any): SuccessfulRequest<User> {
    return {
      successful: true,
      result: req.user,
    };
  }
}
