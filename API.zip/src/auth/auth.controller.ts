import {
  Body,
  Controller,
  Post,
  UseGuards,
} from '@nestjs/common';
import { ApiBody, ApiResponse, ApiTags } from '@nestjs/swagger';

import { Observable } from 'rxjs';

import { FailedRequest, SuccessfulRequest } from '@models/common.models';

import { AuthorizationGuard } from '@core/authorization.guard';
import { SwaggerFailedRegisterResponse, SwaggerLoginBody, SwaggerLoginResponse, SwaggerRegisterResponse, SwaggerUser } from '@swagger/models';

import { UserModel } from './auth.models';
import { AuthService } from './auth.service';

@Controller()
@ApiTags('Auth')
@UseGuards(AuthorizationGuard)
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('login')
  @ApiBody({
    type: SwaggerLoginBody,
  })
  @ApiResponse({
    status: 200,
    description: 'Successful login',
    type: SwaggerLoginResponse,
  })
  login(
    @Body() body: UserModel,
  ): Observable<SuccessfulRequest<string> | FailedRequest> {
    return this.authService.login(body);
  }

  @Post('register')
  @ApiBody({
    type: SwaggerUser,
  })
  @ApiResponse({
    status: 200,
    description: 'Successful registration',
    type: SwaggerRegisterResponse,
  })
  @ApiResponse({
    status: 400,
    description: 'Failed registration',
    type: SwaggerFailedRegisterResponse,
  })
  register(
    @Body() body: UserModel,
  ): Observable<SuccessfulRequest<string> | FailedRequest> {
    return this.authService.register(body);
  }
}
