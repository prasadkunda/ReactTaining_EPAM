import { ApiProperty } from "@nestjs/swagger";

export class SwaggerCourse {
  @ApiProperty()
  title: string;

  @ApiProperty()
  description: string;

  @ApiProperty()
  duration: number;

  @ApiProperty()
  authors: string[];
}

export class SwaggerCoursesResponse {
  @ApiProperty()
  successful: boolean;

  @ApiProperty({ type: [SwaggerCourse] })
  result: SwaggerCourse[];
}

export class SwaggerCourseResponse {
  @ApiProperty()
  successful: boolean;

  @ApiProperty({ type: SwaggerCourse })
  result: SwaggerCourse;
}

export class SwaggerCoursesDeleteResponse {
  @ApiProperty()
  successful: boolean;

  @ApiProperty()
  result: string;
}

export class SwaggerUser {
  @ApiProperty()
  name: string;

  @ApiProperty()
  email: string;

  @ApiProperty()
  password: string;
}

export class SwaggerUserFull extends SwaggerUser {
  @ApiProperty()
  id: string;

  @ApiProperty()
  role: 'admin' | 'user';
}

export class SwaggerLoginBody {
  @ApiProperty({ example: "user@example.com" })
  email: string;

  @ApiProperty({ example: "password123" })
  password: string;
}

export class SwaggerLoginResponse {
  @ApiProperty({ example: true })
  successful: boolean;

  @ApiProperty({ example: 'Bearer of/Ki3xuz.....qZbyN5gM4PN60g==' })
  result: string;

  @ApiProperty({ type: SwaggerUser })
  user: SwaggerUser;
}

export class SwaggerRegisterResponse {
  @ApiProperty({ example: true })
  successful: boolean;

  @ApiProperty({ example: "User was created." })
  result: string;
}

export class SwaggerFailedRegisterResponse {
  @ApiProperty({ example: true })
  successful: boolean;

  @ApiProperty({ example: "'email' should be a string and it should be an email or email already exists" })
  emailError: string;

  @ApiProperty({ example: "'password' should be a string and length should be 6 characters minimum" })
  passwordError: string;
}

export class SwaggerUserResponse {
  @ApiProperty({ example: true })
  successful: boolean;

  @ApiProperty({ type: SwaggerUserFull })
  result: SwaggerUserFull;
}
  

export class SwaggerAuthor {
  @ApiProperty()
  name: string;
}

export class SwaggerAuthorFull extends SwaggerAuthor {
  @ApiProperty()
  id: string;
}

export class SwaggerAuthorsResponse {
  @ApiProperty({ example: true })
  successful: boolean;

  @ApiProperty({ type: [SwaggerAuthorFull] })
  result: SwaggerAuthorFull[];
}

export class SwaggerAuthorResponse {
  @ApiProperty({ example: true })
  successful: boolean;

  @ApiProperty({ type: SwaggerAuthorFull })
  result: SwaggerAuthorFull;
}

export class SwaggerAuthorDeleteResponse {
  @ApiProperty()
  successful: boolean;

  @ApiProperty()
  result: string;
}
