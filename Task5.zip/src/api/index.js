import { IMPORTANCE, TODO_API_URL } from "../contants";

export const fetchTodosService = async () => {
  const response = await fetch(TODO_API_URL);
  const data = await response.json();

  const importanceMapping = {
    3: IMPORTANCE.HIGH,
    4: IMPORTANCE.MEDIUM,
    7: IMPORTANCE.HIGH,
    8: IMPORTANCE.MEDIUM,
    12: IMPORTANCE.HIGH,
    13: IMPORTANCE.MEDIUM,
    15: IMPORTANCE.MEDIUM,
    17: IMPORTANCE.HIGH,
  };

  return new Promise((resolve) => {
    setTimeout(() => {
      resolve(
        data
          .splice(0, 20)
          .map((item) => {
            return {
              ...item,
              importance: importanceMapping[item.id] || IMPORTANCE.LOW,
            };
          })
          .reverse()
      );
    }, 1000);
  });
};

export const updateTodoService = async (todo) => {
  return fetch(TODO_API_URL, {
    method: "POST",
    body: JSON.stringify(todo),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  }).then((response) => response.json());
};

export const createTodoService = async (todo) => {
  return fetch(TODO_API_URL, {
    method: "POST",
    body: JSON.stringify(todo),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  }).then((response) => response.json());
};

export const deleteTodoService = async (todo) => {
  return fetch(TODO_API_URL, {
    method: "POST",
    body: JSON.stringify(todo),
    headers: {
      "Content-type": "application/json; charset=UTF-8",
    },
  }).then((response) => response.json());
};
