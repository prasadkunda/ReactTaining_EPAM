export const IMPORTANCE = {
  HIGH: "high",
  MEDIUM: "medium",
  LOW: "low",
};

export const TODO_API_URL = "https://jsonplaceholder.typicode.com/todos";
