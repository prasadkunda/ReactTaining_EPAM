import { render, screen } from "@testing-library/react";
import { Provider } from "react-redux";
import { MemoryRouter } from "react-router-dom";
import configureStore from "redux-mock-store";
import App from "./App";

const mockStore = configureStore([]);

describe("App Component", () => {
  let store;

  beforeEach(() => {
    store = mockStore({
      token: null,
      isLoaded: false,
    });
  });

  test("renders Header component", () => {
    render(
      <Provider store={store}>
        <MemoryRouter>
          <App />
        </MemoryRouter>
      </Provider>
    );
    expect(screen.getByRole("heading")).toBeInTheDocument(); // Assuming Header has a heading
  });

  test("renders Login route when not authenticated", () => {
    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={["/login"]}>
          <App />
        </MemoryRouter>
      </Provider>
    );
    expect(screen.getByText(/login/i)).toBeInTheDocument(); // Assuming Login has text "Login"
  });

  test("renders Todos route when authenticated", () => {
    store = mockStore({
      token: "mockToken",
      isLoaded: true,
    });

    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={["/"]}>
          <App />
        </MemoryRouter>
      </Provider>
    );
    expect(screen.getByText(/todos/i)).toBeInTheDocument(); // Assuming Todos has text "Todos"
  });

  test("does not render Todos route when not loaded", () => {
    store = mockStore({
      token: null,
      isLoaded: false,
    });

    render(
      <Provider store={store}>
        <MemoryRouter initialEntries={["/"]}>
          <App />
        </MemoryRouter>
      </Provider>
    );
    expect(screen.queryByText(/todos/i)).toBeInTheDocument();
  });
});
