import { createTodoId } from "../createTodoId";

describe("utils", () => {
  it("should return 1 when the todos array is empty", () => {
    const todos = [];
    const newId = createTodoId(todos);
    expect(newId).toBe(1);
  });

  it("should return 1 when the todos array is undefined", () => {
    const newId = createTodoId(undefined);
    expect(newId).toBe(1);
  });

  it("should return the highest id + 1 when there are multiple todos", () => {
    const todos = [
      { id: 1, text: "First todo" },
      { id: 2, text: "Second todo" },
      { id: 5, text: "Fifth todo" },
    ];
    const newId = createTodoId(todos);
    expect(newId).toBe(6);
  });

  it("should handle non-consecutive ids correctly", () => {
    const todos = [
      { id: 10, text: "Tenth todo" },
      { id: 4, text: "Fourth todo" },
      { id: 7, text: "Seventh todo" },
    ];
    const newId = createTodoId(todos);
    expect(newId).toBe(11);
  });

  it("should handle todos with zero id", () => {
    const todos = [
      { id: 0, text: "Zero id todo" },
      { id: 2, text: "Second todo" },
      { id: 1, text: "First todo" },
    ];
    const newId = createTodoId(todos);
    expect(newId).toBe(3);
  });
});
