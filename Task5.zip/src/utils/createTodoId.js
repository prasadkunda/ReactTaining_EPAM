export const createTodoId = (todos = []) => {
  let highestId = 0;

  todos.forEach((item) => {
    if (item.id > highestId) {
      highestId = item.id;
    }
  });

  return highestId + 1;
};
