export class LocalStorageUtil {
  static setItem(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch (e) {
      console.error("Error saving to localStorage", e);
    }
  }

  static getItem(key) {
    try {
      return localStorage.getItem(key);
    } catch (e) {
      console.error("Error getting data from localStorage", e);
      return null;
    }
  }

  static removeItem(key) {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.error("Error removing data from localStorage", e);
    }
  }

  static clear() {
    try {
      localStorage.clear();
    } catch (e) {
      console.error("Error clearing localStorage", e);
    }
  }
}
