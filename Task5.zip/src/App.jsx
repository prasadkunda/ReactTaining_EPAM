import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Route, Routes } from "react-router";
import { getTodosThunk } from "./store/thunks";
import { getIsLoadedSelector, getTokenSelector } from "./store/selectors";
import { Todos } from "./components/Todos";
import { Login } from "./components/Login";
import { CreateTodo } from "./components/CreateTodo";
import { Header } from "./components/Header";
import { ProtectedRoute } from "./components/ProtectedRoute";
import styles from "./App.module.css";

function App() {
  const dispatch = useDispatch();
  const token = useSelector(getTokenSelector);
  const isLoaded = useSelector(getIsLoadedSelector);

  useEffect(() => {
    if (token && !isLoaded) {
      dispatch(getTodosThunk());
    }
  }, [token, isLoaded, dispatch]);

  return (
    <>
      <Header />
      <div className={styles.content}>
        <Routes>
          <Route
            path="/"
            element={
              <ProtectedRoute>
                <Todos />
              </ProtectedRoute>
            }
          />
          <Route
            path="/todos"
            element={
              <ProtectedRoute>
                <Todos />
              </ProtectedRoute>
            }
          />
          <Route
            path="/create"
            element={
              <ProtectedRoute>
                <CreateTodo />
              </ProtectedRoute>
            }
          />
          <Route path="/login" element={<Login />} />
        </Routes>
      </div>
    </>
  );
}

export default App;
