import { useState, useRef, useCallback, useEffect } from "react";

export const useStateWithCallback = (initialState) => {
  const [state, setState] = useState(initialState);
  const callBackRef = useRef(null);

  const setStateWithCallback = useCallback((state, callback) => {
    callBackRef.current = callback;
    setState(state);
  }, []);

  useEffect(() => {
    if (callBackRef.current) {
      callBackRef.current(state);
      callBackRef.current = null;
    }
  }, [state]);

  return [state, setStateWithCallback];
};
