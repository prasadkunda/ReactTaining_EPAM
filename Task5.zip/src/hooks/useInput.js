import { useState } from "react";

export const useInput = (initialValue = "", minLength = 2) => {
  const [value, setValue] = useState(initialValue);
  const [isValid, setIsValid] = useState(true);

  const onChange = (e) => {
    setIsValid(true);
    setValue(e.target.value);
  };

  const validate = () => {
    if (value.length > minLength) {
      return true;
    }

    setIsValid(false);
    return false;
  };

  return [value, onChange, isValid, validate];
};
