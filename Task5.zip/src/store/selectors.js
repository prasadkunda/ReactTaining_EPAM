export const getTodosSelector = (state) => state.todos?.items;
export const getIsLoadedSelector = (state) => state.todos?.isLoaded;

export const getTokenSelector = (state) => state.user?.token;
