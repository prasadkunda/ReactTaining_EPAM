import { configureStore } from "@reduxjs/toolkit";
import todosSlice from "./slices/todosSlice";
import userSlice from "./slices/userSlice";

const reducer = {
  todos: todosSlice,
  user: userSlice,
};

const store = configureStore({
  reducer,
});

export const mockStore = (preloadedState) =>
  configureStore({
    preloadedState,
    reducer,
  });

export default store;
