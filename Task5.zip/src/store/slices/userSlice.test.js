import { setToken, userSlice } from "./userSlice";

describe("userSlice", () => {
  let state;
  const initialState = { token: null }; // Define initialState

  beforeEach(() => {
    state = { token: null };
  });

  it("should return the initial state", () => {
    expect(userSlice.reducer(undefined, {})).toEqual(initialState);
  });

  it("should handle setToken", () => {
    const token = "testToken";
    const action = setToken(token);
    const newState = userSlice.reducer(state, action);
    expect(newState.token).toEqual(token);
  });
});
