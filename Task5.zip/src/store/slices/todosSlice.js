import { createSlice } from "@reduxjs/toolkit";

const initialState = { isLoaded: false, items: [] };

export const todosSlice = createSlice({
  name: "todos",
  initialState,
  reducers: {
    setTodos: (state, { payload }) => ({
      ...state,
      isLoaded: true,
      items: payload,
    }),
    updateTodo: (state, { payload }) => {
      state.items = state.items.map((item) => {
        if (
          item.title === payload.title &&
          item.importance === payload.importance
        ) {
          return {
            ...item,
            ...payload,
            id: item.id,
            changed: false,
            loading: false,
          };
        }
        return item;
      });
    },
    setChecked: (state, { payload }) => {
      state.items = state.items.map((item) => {
        if (item.id === payload) {
          return { ...item, completed: !item.completed, changed: true };
        }
        return item;
      });
    },
    setImportance: (state, { payload }) => {
      state.items = state.items.map((item) => {
        if (item.id === payload.id) {
          return { ...item, importance: payload.importance, changed: true };
        }
        return item;
      });
    },
    setTitle: (state, { payload }) => {
      state.items = state.items.map((item) => {
        if (item.id === payload.id) {
          return { ...item, title: payload.title, changed: true };
        }

        return item;
      });
    },
    setTodoLoading: (state, { payload }) => {
      state.items = state.items.map((item) => {
        if (item.id === payload.id) {
          return { ...item, loading: payload.loading };
        }

        return item;
      });
    },
    addTodo: (state, { payload }) => {
      state.items = [payload, ...state.items];
    },
    deleteTodo: (state, { payload }) => {
      state.items = state.items.filter((item) => item.id !== payload);
    },
  },
});

export const {
  setTodos,
  updateTodo,
  setChecked,
  setImportance,
  setTitle,
  addTodo,
  setTodoLoading,
  deleteTodo,
} = todosSlice.actions;

export default todosSlice.reducer;
