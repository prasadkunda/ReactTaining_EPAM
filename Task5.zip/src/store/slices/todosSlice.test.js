import {
  addTodo,
  deleteTodo,
  setChecked,
  setImportance,
  setTitle,
  setTodoLoading,
  setTodos,
  todosSlice,
  updateTodo,
} from "./todosSlice";

describe("todosSlice", () => {
  let initialState;

  beforeEach(() => {
    initialState = { isLoaded: false, items: [] };
  });

  it("should handle setTodos", () => {
    const action = setTodos([
      { id: 1, title: "Test Todo", importance: "high" },
    ]);
    const state = todosSlice.reducer(initialState, action);
    expect(state).toEqual({ isLoaded: true, items: action.payload });
  });

  it("should handle updateTodo", () => {
    const stateWithItems = {
      ...initialState,
      items: [
        {
          id: 1,
          title: "Test Todo",
          importance: "high",
          completed: false,
          changed: false,
          loading: false,
        },
      ],
    };
    const action = updateTodo({
      id: 1,
      title: "Updated Todo",
      importance: "low",
    });
    const state = todosSlice.reducer(stateWithItems, action);
    expect(state.items[0]).toEqual({
      id: 1,
      title: "Test Todo",
      importance: "high",
      completed: false,
      changed: false,
      loading: false,
    });
  });

  it("should handle setChecked", () => {
    const stateWithItems = {
      ...initialState,
      items: [{ id: 1, title: "Test Todo", completed: false }],
    };
    const action = setChecked(1);
    const state = todosSlice.reducer(stateWithItems, action);
    expect(state.items[0].completed).toBe(true);
    expect(state.items[0].changed).toBe(true);
  });

  it("should handle setImportance", () => {
    const stateWithItems = {
      ...initialState,
      items: [{ id: 1, title: "Test Todo", importance: "low" }],
    };
    const action = setImportance({ id: 1, importance: "high" });
    const state = todosSlice.reducer(stateWithItems, action);
    expect(state.items[0].importance).toBe("high");
    expect(state.items[0].changed).toBe(true);
  });

  it("should handle setTitle", () => {
    const stateWithItems = {
      ...initialState,
      items: [{ id: 1, title: "Test Todo" }],
    };
    const action = setTitle({ id: 1, title: "Updated Title" });
    const state = todosSlice.reducer(stateWithItems, action);
    expect(state.items[0].title).toBe("Updated Title");
    expect(state.items[0].changed).toBe(true);
  });

  it("should handle setTodoLoading", () => {
    const stateWithItems = {
      ...initialState,
      items: [{ id: 1, title: "Test Todo", loading: false }],
    };
    const action = setTodoLoading({ id: 1, loading: true });
    const state = todosSlice.reducer(stateWithItems, action);
    expect(state.items[0].loading).toBe(true);
  });

  it("should handle addTodo", () => {
    const action = addTodo({ id: 1, title: "New Todo", importance: "medium" });
    const state = todosSlice.reducer(initialState, action);
    expect(state.items).toEqual([action.payload]);
  });

  it("should handle deleteTodo", () => {
    const stateWithItems = {
      ...initialState,
      items: [
        { id: 1, title: "Test Todo" },
        { id: 2, title: "Another Todo" },
      ],
    };
    const action = deleteTodo(1);
    const state = todosSlice.reducer(stateWithItems, action);
    expect(state.items).toEqual([{ id: 2, title: "Another Todo" }]);
  });
});
