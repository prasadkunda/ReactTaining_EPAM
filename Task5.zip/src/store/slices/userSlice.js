import { createSlice } from "@reduxjs/toolkit";
import { LocalStorageUtil } from "../../utils/LocalStorage";

const initialState = { token: LocalStorageUtil.getItem("token") };

export const userSlice = createSlice({
  name: "todos",
  initialState,
  reducers: {
    setToken: (state, { payload }) => ({
      token: payload,
    }),
  },
});

export const { setToken } = userSlice.actions;

export default userSlice.reducer;
