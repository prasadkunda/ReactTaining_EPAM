import {
  createTodoService,
  deleteTodoService,
  fetchTodosService,
  updateTodoService,
} from "../../api";
import {
  updateTodo,
  setTodos,
  addTodo,
  setTodoLoading,
  deleteTodo,
} from "../slices/todosSlice";

export const getTodosThunk = () => async (dispatch) => {
  const response = await fetchTodosService();

  dispatch(setTodos(response));
};

export const saveTodoThunk = (todo) => async (dispatch) => {
  dispatch(setTodoLoading({ loading: true, id: todo.id }));
  const response = await updateTodoService(todo);

  dispatch(updateTodo(response));
};

export const addTodoThunk = (todo) => async (dispatch) => {
  const response = await createTodoService(todo);

  return new Promise((resolve) => {
    dispatch(addTodo({ ...response, id: todo.id }));

    return resolve();
  });
};

export const deleteTodoThunk = (todo) => async (dispatch) => {
  dispatch(setTodoLoading({ loading: true, id: todo.id }));
  await deleteTodoService(todo);

  dispatch(deleteTodo(todo.id));
};
