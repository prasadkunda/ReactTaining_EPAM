import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import { CreateTodo } from "./index";
import { IMPORTANCE } from "../../contants";
import configureStore from "redux-mock-store";

const mockStore = configureStore([]);

jest.mock("../../store/thunks");
jest.mock("react-router-dom", () => ({
  ...jest.requireActual("react-router-dom"),
  useNavigate: () => jest.fn(),
}));

describe("CreateTodo Component", () => {
  let store;
  const initialState = {
    todos: {
      todos: [],
      isLoaded: true,
    },
  };

  beforeEach(() => {
    store = mockStore(initialState);
    store.dispatch = jest.fn(() => Promise.resolve());
  });

  const renderComponent = () => {
    return render(
      <Provider store={store}>
        <BrowserRouter>
          <CreateTodo />
        </BrowserRouter>
      </Provider>
    );
  };

  test("renders form when isLoaded is true", () => {
    renderComponent();
    expect(screen.getByText("Create Todo")).toBeInTheDocument();
    expect(
      screen.getByPlaceholderText("Min length - 20 characters")
    ).toBeInTheDocument();
  });

  test("updates title input", () => {
    renderComponent();
    const input = screen.getByPlaceholderText("Min length - 20 characters");
    fireEvent.change(input, { target: { value: "New Todo Title" } });
    expect(input.value).toBe("New Todo Title");
  });

  test("disables submit button when title is less than 10 characters", () => {
    renderComponent();
    const button = screen.getByRole("button", { name: /Add Todo/i });
    expect(button).toBeDisabled();
  });

  test("enables submit button when title has 10+ characters", () => {
    renderComponent();
    const input = screen.getByPlaceholderText("Min length - 20 characters");
    fireEvent.change(input, { target: { value: "Valid Todo Title" } });
    const button = screen.getByRole("button", { name: /Add Todo/i });
    expect(button).not.toBeDisabled();
  });

  test("updates importance value", () => {
    renderComponent();
    const select = screen.getByDisplayValue(IMPORTANCE.LOW);
    fireEvent.change(select, { target: { value: IMPORTANCE.HIGH } });
    expect(select.value).toBe(IMPORTANCE.HIGH);
  });

  test("updates completed checkbox", () => {
    renderComponent();
    const checkbox = screen.getByRole("checkbox");
    fireEvent.click(checkbox);
    expect(checkbox).toBeChecked();
  });

  test("renders Loader when isLoaded is false", () => {
    store = mockStore({ todos: { todos: [], isLoaded: false } });
    render(
      <Provider store={store}>
        <BrowserRouter>
          <CreateTodo />
        </BrowserRouter>
      </Provider>
    );
    expect(screen.queryByText("Create Todo")).not.toBeInTheDocument();
  });
});
