import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";
import { addTodoThunk } from "../../store/thunks";
import { getIsLoadedSelector, getTodosSelector } from "../../store/selectors";
import { IMPORTANCE } from "../../contants";
import { createTodoId } from "../../utils/createTodoId";
import { Loader } from "../Loader";
import styles from "./styles.module.css";

const importanceList = [IMPORTANCE.LOW, IMPORTANCE.MEDIUM, IMPORTANCE.HIGH];

export const CreateTodo = () => {
  const [title, setTitle] = useState("");
  const [importance, setImportance] = useState(IMPORTANCE.LOW);
  const [completed, setCompleted] = useState(false);
  const todos = useSelector(getTodosSelector);
  const isLoaded = useSelector(getIsLoadedSelector);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const todo = { title, importance, completed, id: createTodoId(todos) };

    await dispatch(addTodoThunk(todo));

    navigate("/");
  };

  return isLoaded ? (
    <div className={styles.formContainer}>
      <h1>Create Todo</h1>
      <form className={styles.form} onSubmit={handleSubmit}>
        <label className={styles.label}>
          Title:
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Min length - 20 characters"
            required
          />
        </label>
        <label className={styles.label}>
          Importance:
          <select
            value={importance}
            onChange={(e) => setImportance(e.target.value)}
          >
            {importanceList.map((item) => (
              <option key={item} value={item}>
                {item}
              </option>
            ))}
          </select>
        </label>
        <label className={styles.label}>
          Completed:
          <input
            type="checkbox"
            checked={completed}
            onChange={(e) => setCompleted(e.target.checked)}
          />
        </label>
        <button
          className={styles.button}
          disabled={title.length < 10}
          type="submit"
        >
          Add Todo
        </button>
      </form>
    </div>
  ) : (
    <Loader />
  );
};
