import { render, screen } from "@testing-library/react";
import { BrowserRouter } from "react-router-dom";
import { Header } from "./index";

describe("Header", () => {
  const renderHeader = () => {
    render(
      <BrowserRouter>
        <Header />
      </BrowserRouter>
    );
  };

  it("renders without crashing", () => {
    renderHeader();
    expect(screen.getByRole("link", { name: /todos/i })).toBeInTheDocument();
  });

  it("renders todos link with correct href", () => {
    renderHeader();
    const todosLink = screen.getByRole("link", { name: /todos/i });
    expect(todosLink).toHaveAttribute("href", "/todos");
  });

  it("renders create todo link with correct href", () => {
    renderHeader();
    const createLink = screen.getByRole("link", { name: /create todo/i });
    expect(createLink).toHaveAttribute("href", "/create");
  });

  it("renders both navigation links", () => {
    renderHeader();
    expect(screen.getByRole("link", { name: /todos/i })).toBeInTheDocument();
    expect(
      screen.getByRole("link", { name: /create todo/i })
    ).toBeInTheDocument();
  });
});
