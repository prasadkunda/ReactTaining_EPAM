import { useSelector } from "react-redux";
import { getIsLoadedSelector, getTodosSelector } from "../../store/selectors";
import { TodoItem } from "./TodoItem";
import { Loader } from "../Loader";

export const Todos = () => {
  const todos = useSelector(getTodosSelector);
  const isLoaded = useSelector(getIsLoadedSelector);

  return isLoaded ? (
    todos?.map((todo) => <TodoItem {...todo} key={todo.id} />)
  ) : (
    <Loader />
  );
};
