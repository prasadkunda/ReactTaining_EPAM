import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { configureStore } from "@reduxjs/toolkit";
import { TodoItem } from "./index";
import todosReducer from "../../../store/slices/todosSlice";
import { IMPORTANCE } from "../../../contants";

jest.mock("../../../store/thunks");
jest.mock("../../Loader", () => ({
  Loader: () => <div data-testid="loader">Loader</div>,
}));

const createMockStore = () =>
  configureStore({
    reducer: {
      todos: todosReducer,
    },
  });

const defaultTodo = {
  id: 1,
  title: "Test Todo",
  completed: false,
  changed: false,
  loading: false,
  importance: IMPORTANCE.LOW,
};

const renderWithRedux = (component, store = createMockStore()) => {
  return render(<Provider store={store}>{component}</Provider>);
};

describe("TodoItem", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("renders todo item with title", () => {
    renderWithRedux(<TodoItem {...defaultTodo} />);
    expect(screen.getByText("Test Todo")).toBeInTheDocument();
  });

  test("renders loader when loading is true", () => {
    renderWithRedux(<TodoItem {...defaultTodo} loading={true} />);
    expect(screen.getByTestId("loader")).toBeInTheDocument();
  });

  test("toggles edit mode on title click", () => {
    renderWithRedux(<TodoItem {...defaultTodo} />);
    fireEvent.click(screen.getByText("Test Todo"));
    expect(screen.getByDisplayValue("Test Todo")).toBeInTheDocument();
  });

  test("saves title on blur", () => {
    const store = createMockStore();
    renderWithRedux(<TodoItem {...defaultTodo} />, store);
    fireEvent.click(screen.getByText("Test Todo"));
    const input = screen.getByDisplayValue("Test Todo");
    fireEvent.change(input, { target: { value: "Updated Todo" } });
    fireEvent.blur(input);
    expect(screen.getByText("Test Todo")).toBeInTheDocument();
  });

  test("calls setChecked dispatch on checkbox change", () => {
    const store = createMockStore();
    renderWithRedux(<TodoItem {...defaultTodo} />, store);
    const checkbox = screen.getByRole("checkbox");
    fireEvent.change(checkbox);
  });

  test("cycles importance on click", () => {
    renderWithRedux(<TodoItem {...defaultTodo} />);
    const importance = screen.getByText(IMPORTANCE.LOW);
    fireEvent.click(importance);
  });

  test("shows save button when changed is true", () => {
    renderWithRedux(<TodoItem {...defaultTodo} changed={true} />);
    expect(screen.getByText("SAVE")).toBeInTheDocument();
  });

  test("hides save button when changed is false", () => {
    renderWithRedux(<TodoItem {...defaultTodo} changed={false} />);
    expect(screen.queryByText("SAVE")).not.toBeInTheDocument();
  });

  test("renders todo id", () => {
    renderWithRedux(<TodoItem {...defaultTodo} />);
    expect(screen.getByText("1")).toBeInTheDocument();
  });
});
