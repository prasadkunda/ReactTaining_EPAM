import { useState, useRef } from "react";
import { useDispatch } from "react-redux";
import clsx from "clsx";
import { string, number, bool, oneOf } from "prop-types";
import { IMPORTANCE } from "../../../contants";
import {
  setChecked,
  setImportance,
  setTitle,
} from "../../../store/slices/todosSlice";
import { deleteTodoThunk, saveTodoThunk } from "../../../store/thunks";
import { useStateWithCallback } from "../../../hooks";
import { Loader } from "../../Loader";
import styles from "./styles.module.css";

export const TodoItem = (todo) => {
  const [title, setTodoTitle] = useState(todo.title);
  const [isEditMode, setIsEditMode] = useStateWithCallback(false);
  const inputRef = useRef();

  const dispatch = useDispatch();
  const onChacked = () => {
    dispatch(setChecked(todo.id));
  };
  const onImportanceClick = () => {
    let newImportance = IMPORTANCE.LOW;

    if (todo.importance === IMPORTANCE.LOW) {
      newImportance = IMPORTANCE.MEDIUM;
    } else if (todo.importance === IMPORTANCE.MEDIUM) {
      newImportance = IMPORTANCE.HIGH;
    }

    dispatch(setImportance({ id: todo.id, importance: newImportance }));
  };

  const onTitleClick = () => {
    setIsEditMode(true, () => {
      inputRef.current.focus();
    });
  };

  const handleSaveTitle = () => {
    dispatch(setTitle({ id: todo.id, title }));
    setIsEditMode(false);
  };

  const onSaveTodo = () => {
    dispatch(saveTodoThunk(todo));
  };

  const onDelete = () => {
    dispatch(deleteTodoThunk(todo));
  };

  return (
    <div className={styles.todoItem} key={todo.id}>
      <div>{todo.id}</div>
      {todo.loading ? (
        <Loader className={styles.loader} />
      ) : (
        <div className={styles.titleWrapper}>
          {isEditMode ? (
            <input
              ref={inputRef}
              type="text"
              value={title}
              onChange={(e) => {
                console.log(e.target.value);
                setTodoTitle(e.target.value);
              }}
              onBlur={handleSaveTitle}
            />
          ) : (
            <div
              onClick={onTitleClick}
              className={clsx(styles.title, { [styles.done]: todo.completed })}
            >
              {todo.title}
            </div>
          )}
        </div>
      )}
      <div>
        <input type="checkbox" checked={todo.completed} onChange={onChacked} />
      </div>
      <div
        className={clsx(styles[todo.importance], styles.importance)}
        onClick={onImportanceClick}
      >
        {todo.importance}
      </div>
      <div className={styles.delete} onClick={onDelete}>
        DELETE
      </div>
      {todo.changed && (
        <button className={styles.saveButton} onClick={onSaveTodo}>
          SAVE
        </button>
      )}
    </div>
  );
};

TodoItem.propTypes = {
  id: number,
  title: string,
  changed: bool,
  completed: bool,
  loading: bool,
  importance: oneOf([IMPORTANCE.LOW, IMPORTANCE.MEDIUM, IMPORTANCE.HIGH]),
};
