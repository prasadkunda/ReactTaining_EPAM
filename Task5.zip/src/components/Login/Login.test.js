import { render, screen, fireEvent } from "@testing-library/react";
import { Provider } from "react-redux";
import { BrowserRouter } from "react-router-dom";
import { configureStore } from "@reduxjs/toolkit";
import { Login } from "./index";
import userReducer from "../../store/slices/userSlice";
import { LocalStorageUtil } from "../../utils/LocalStorage";

jest.mock("../../utils/LocalStorage");

const renderWithProviders = (component) => {
  const store = configureStore({
    reducer: {
      user: userReducer,
    },
  });

  return render(
    <Provider store={store}>
      <BrowserRouter>{component}</BrowserRouter>
    </Provider>
  );
};

describe("Login Component", () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });

  test("renders login form with title and inputs", () => {
    renderWithProviders(<Login />);
    expect(screen.getByText("Login")).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/Any username/i)).toBeInTheDocument();
    expect(screen.getByPlaceholderText(/Any password/i)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /Submit/i })).toBeInTheDocument();
  });

  test("shows validation error when login input is too short", () => {
    renderWithProviders(<Login />);
    const loginInput = screen.getByPlaceholderText(/Any username/i);
    fireEvent.change(loginInput, { target: { value: "a" } });
    fireEvent.click(screen.getByRole("button", { name: /Submit/i }));
    expect(screen.getAllByText(/Min length: 2/i)[0]).toBeInTheDocument();
  });

  test("submits form with valid credentials", () => {
    renderWithProviders(<Login />);
    fireEvent.change(screen.getByPlaceholderText(/Any username/i), {
      target: { value: "testuser" },
    });
    fireEvent.change(screen.getByPlaceholderText(/Any password/i), {
      target: { value: "testpass" },
    });
    fireEvent.click(screen.getByRole("button", { name: /Submit/i }));
    expect(LocalStorageUtil.setItem).toHaveBeenCalledWith(
      "token",
      expect.any(String)
    );
  });
});
