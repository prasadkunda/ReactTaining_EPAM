import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { setToken } from "../../store/slices/userSlice";
import { useInput } from "../../hooks/useInput";
import { LocalStorageUtil } from "../../utils/LocalStorage";
import styles from "./styles.module.css";

export const Login = () => {
  const navigate = useNavigate();
  const [login, setLogin, isLoginValid, validateLogin] = useInput("", 2);
  const [password, setPassword, isPasswordValid, validatePassword] = useInput(
    "",
    2
  );

  const dispatch = useDispatch();
  const isValid = () => validateLogin() && validatePassword();

  const onSubmit = () => {
    if (isValid()) {
      const token = JSON.stringify({ login, password });
      LocalStorageUtil.setItem("token", token);
      dispatch(setToken(token));

      navigate("/todos");
    }
  };

  return (
    <div className={styles.loginContainer}>
      <h1>Login</h1>
      <label>
        <input
          className={styles.input}
          value={login}
          onChange={setLogin}
          type="text"
          placeholder="Any username with length > 2"
        />
        {!isLoginValid && <p style={{ color: "red" }}> Min length: 2 </p>}
      </label>
      <label>
        <input
          className={styles.input}
          value={password}
          onChange={setPassword}
          type="password"
          placeholder="Any password with length > 2"
        />
        {!isPasswordValid && <p style={{ color: "red" }}> Min length: 2 </p>}
      </label>

      <button onClick={onSubmit}>Submit</button>
    </div>
  );
};
