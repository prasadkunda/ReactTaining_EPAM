import { Navigate } from "react-router-dom";
import { useSelector } from "react-redux";
import { getTokenSelector } from "../../store/selectors";

export const ProtectedRoute = ({ children }) => {
  const token = useSelector(getTokenSelector);

  return token ? children : <Navigate to={"/login"} />;
};
