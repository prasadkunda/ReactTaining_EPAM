import { render } from "@testing-library/react";
import { Loader } from "./index";
import styles from "./styles.module.css";

describe("Loader", () => {
  it("should render without crashing", () => {
    const { container } = render(<Loader />);
    expect(container).toBeInTheDocument();
  });

  it("should apply the loader style class", () => {
    const { container } = render(<Loader />);
    const loader = container.firstChild;
    expect(loader).toHaveClass(styles.loader);
  });

  it("should apply custom className prop", () => {
    const customClass = "custom-loader";
    const { container } = render(<Loader className={customClass} />);
    const loader = container.firstChild;
    expect(loader).toHaveClass(customClass);
  });

  it("should apply both loader style and custom className", () => {
    const customClass = "custom-loader";
    const { container } = render(<Loader className={customClass} />);
    const loader = container.firstChild;
    expect(loader).toHaveClass(styles.loader);
    expect(loader).toHaveClass(customClass);
  });

  it("should render a div element", () => {
    const { container } = render(<Loader />);
    const loader = container.firstChild;
    expect(loader.tagName).toBe("DIV");
  });
});
