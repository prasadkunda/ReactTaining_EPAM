import clsx from "clsx";
import { string } from "prop-types";
import styles from "./styles.module.css";

export const Loader = ({ className }) => (
  <div className={clsx(styles.loader, className)} />
);

Loader.propTypes = {
  className: string,
};
