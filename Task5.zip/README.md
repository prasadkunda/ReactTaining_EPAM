# Home task for [React Fundamentals](https://learn.epam.com/detailsPage?id=e69f3b41-ea94-451d-927d-c4331c145878) Module 5

### Please study the material under Module 5 [React Tests](https://ebook.learn.epam.com/new-react-fundamentals/docs/category/module-5---react-tests) topics in the coursebook first.

## How to start writing tests

### `npm install` - command will install all necessary dependencies

### `npm run start` - command will start the app you should test 
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### `npm run test:local` - command will reload tests if you make edits

### `npm run test:coverage` - command will print in terminal current tests coverage