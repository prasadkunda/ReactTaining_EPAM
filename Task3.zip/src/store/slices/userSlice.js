import { createSlice } from "@reduxjs/toolkit";

const initialToken = localStorage.getItem("token");

const initialState = {
  isAuth: Boolean(initialToken),
  name: "",
  email: "",
  token: initialToken || null,
};

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setUserData(state, action) {
      const { name, email, token } = action.payload || {};
      if (name !== undefined) state.name = name;
      if (email !== undefined) state.email = email;
      if (token !== undefined) state.token = token;
      if (token) {
        localStorage.setItem("token", token);
      }

      //state.isAuth = Boolean(state.token);
    },

    // Clear user data and de-authenticate
    removeUserData(state) {
      state.name = "";
      state.email = "";
      state.token = null;
      state.isAuth = false;

      // Remove persisted token
      localStorage.removeItem("token");
    },
  },
});

export const { setUserData, removeUserData } = userSlice.actions;

export default userSlice.reducer;
