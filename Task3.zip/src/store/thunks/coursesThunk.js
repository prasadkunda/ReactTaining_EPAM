// export const updateCourseThunk = () => {};

// export const deleteCourseThunk = () => {};

// export const createCourseThunk = () => {};

// export const getCoursesThunk = () => {};
