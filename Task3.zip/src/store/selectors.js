// Module 3:
// * create selectors

export const getCoursesSelector = (state) => null;
export const getAuthorsSelector = (state) => null;
export const getUserNameSelector = (state) => state.user.name;
export const getUserRoleSelector = (state) => null;
export const getUserTokenSelector = (state) => state.user.token;
