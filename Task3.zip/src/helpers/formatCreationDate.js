export const formatCreationDate = (date) => date.replaceAll("/", ".");
