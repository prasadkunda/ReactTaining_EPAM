// Module 1.
// You don't need this component for Module 1.

// Module 2.
// * Uncomment component code with imports
// * Use this component for author creation functionality
// * Pass callback 'onCreateAuthor' from CourseForm.jsx to return author's info {id: string, name: string}

// Module 3.
// Remove 'onCreateAuthor' from props => use 'dispatch' and 'saveAuthor' from 'authorsSlice.js' to save new author to the store

import React, { useState } from "react";
import styles from "./styles.module.css";
import { Button, Input } from "../../../../common";
import { useDispatch } from "react-redux";
import { createAuthorThunk } from "../../../../store/thunks/authorsThunk";

export const CreateAuthor = ({ onCreateAuthor }) => {
  // write your code here
  const [value, setValue] = useState("");
  const dispatch = useDispatch();

  const onChange = (e) => {
    setValue(e.target.value);
  };

  const handleCreateAuthor = () => {
    if (onCreateAuthor) {
      onCreateAuthor(value);
      setValue("");
    } else {
      // Module 4: dispatch thunk when onCreateAuthor is not provided
      dispatch(createAuthorThunk({ name: value }));
      setValue("");
    }
  };
  return (
    <div className={styles.newAuthorContainer}>
      <h2>Author Name</h2>
      <Input
        label="Author Name"
        data-testid="createAuthorInput"
        placeholderText="Enter author name"
        onChange={onChange}
        value={value}
        name="authorName"
      />
      <Button
        data-testid="createAuthorButton"
        buttonText="Create Author"
        handleClick={handleCreateAuthor}
      ></Button>
    </div>
  );
};
