import React from "react";
import { Link, useNavigate, useParams } from "react-router-dom";

import styles from "./styles.module.css";
import { Button, Input } from "../../common";
import { AuthorItem, CreateAuthor } from "./components";
import { getCourseDuration } from "../../helpers";

import { useDispatch, useSelector } from "react-redux";
import { getAuthorsSelector } from "../../store/selectors";
import { createAuthorThunk } from "../../store/thunks/authorsThunk";
import {
  createCourseThunk,
  updateCourseThunk,
} from "../../store/thunks/coursesThunk";

export const CourseForm = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { courseId } = useParams();
  const authorsList = useSelector(getAuthorsSelector) || [];
  const courses = useSelector((state) => state.courses) || [];

  const courseToEdit = courses.find((c) => c.id === courseId);
  const isEditMode = Boolean(courseId);

  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [duration, setDuration] = React.useState(0);
  const [courseAuthors, setCourseAuthors] = React.useState([]);
  const [availableAuthors, setAvailableAuthors] = React.useState([]);

  React.useEffect(() => {
    if (isEditMode && courseToEdit && authorsList.length) {
      setTitle(courseToEdit.title || "");
      setDescription(courseToEdit.description || "");
      setDuration(courseToEdit.duration || 0);

      const assignedAuthors = authorsList.filter((author) =>
        courseToEdit.authors.includes(author.id)
      );

      setCourseAuthors(assignedAuthors);
      setAvailableAuthors(
        authorsList.filter(
          (author) => !courseToEdit.authors.includes(author.id)
        )
      );
    } else {
      setAvailableAuthors(authorsList || []);
    }
  }, [authorsList, courseToEdit, isEditMode]);

  const onChangeTitle = (e) => setTitle(e.target.value);
  const onChangeDescription = (e) => setDescription(e.target.value);
  const onChangeDuration = (e) => setDuration(Number(e.target.value || 0));

  const deleteAuthorItem = (author) => {
    setCourseAuthors((prev) => {
      const exists = prev.some((a) => a.id === author.id);
      return exists ? prev : [...prev, author];
    });
    setAvailableAuthors((prev) => prev.filter((a) => a.id !== author.id));
  };

  const handleDeleteAuthor = (author) => {
    setCourseAuthors((prev) => prev.filter((a) => a.id !== author.id));
    setAvailableAuthors((prev) => {
      const exists = prev.some((a) => a.id === author.id);
      return exists ? prev : [...prev, author];
    });
  };

  const handleCreateAuthor = async (authorName) => {
    const name = typeof authorName === "string" ? authorName : authorName?.name;
    const trimmedName = name?.trim();
    if (!trimmedName) return;

    try {
      const createdAuthor = await dispatch(
        createAuthorThunk({ name: trimmedName })
      );

      if (createdAuthor) {
        setAvailableAuthors((prev) => {
          const exists = prev.some((a) => a.id === createdAuthor.id);
          return exists ? prev : [...prev, createdAuthor];
        });
      }
    } catch (err) {
      console.error("Failed to create author", err);
    }
  };

  const isFormValid = () => {
    return title.length >= 2 && description.length >= 2 && duration > 0;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (!isFormValid()) return;

    const courseData = {
      title,
      description,
      duration,
      authors: courseAuthors.map((c) => c.id),
    };

    try {
      if (isEditMode) {
        await dispatch(updateCourseThunk({ id: courseId, data: courseData }));
      } else {
        await dispatch(createCourseThunk(courseData));
      }

      navigate("/courses");
    } catch (err) {
      console.error("Failed to submit course", err);
    }
  };

  return (
    <div className={styles.container}>
      <h2>Course Edit or Create Page</h2>

      <form onSubmit={onSubmit}>
        <Input
          label="Title"
          data-testid="titleInput"
          placeholderText="Enter title"
          onChange={onChangeTitle}
          value={title}
          name="title"
        />
        <label>
          Description
          <textarea
            className={styles.description}
            data-testid="descriptionTextArea"
            value={description}
            onChange={onChangeDescription}
          />
        </label>
        <div className={styles.infoWrapper}>
          <div>
            <div className={styles.duration}>
              <Input
                labelText="Duration"
                data-testid="durationInput"
                placeholderText="Input text"
                value={duration}
                onChange={onChangeDuration}
                name="duration"
                type="number"
              />
              <p>{getCourseDuration(duration)}</p>
            </div>
            <h2>Authors</h2>
            <div className={styles.authorsSection}>
              <CreateAuthor onCreateAuthor={handleCreateAuthor} />
            </div>

            <div className={styles.authorsContainer}>
              <h3>Authors List</h3>
              {availableAuthors && availableAuthors.length > 0 ? (
                availableAuthors.map((author) => (
                  <AuthorItem
                    key={author.id}
                    author={author}
                    deleteAuthorItem={deleteAuthorItem}
                  />
                ))
              ) : (
                <p className={styles.notification}>Authors list is empty</p>
              )}
            </div>
          </div>

          <div className={styles.courseAuthorsContainer}>
            <h2>Course authors</h2>
            {courseAuthors && courseAuthors.length > 0 ? (
              courseAuthors.map((courseAuthor) => (
                <AuthorItem
                  key={courseAuthor.id}
                  author={courseAuthor}
                  deleteAuthorItem={handleDeleteAuthor}
                />
              ))
            ) : (
              <p className={styles.notification}>Course Author </p>
            )}
          </div>
        </div>

        <div className={styles.buttonsContainer}>
          <Button
            buttonText={isEditMode ? "UPDATE COURSE" : "CREATE COURSE"}
            type="submit"
            disabled={!isFormValid()}
            data-testid="createCourseButton"
            handleClick={onSubmit}
          ></Button>

          <Link to="/courses">
            <Button buttonText="CANCEL" />
          </Link>
        </div>
      </form>
    </div>
  );
};
