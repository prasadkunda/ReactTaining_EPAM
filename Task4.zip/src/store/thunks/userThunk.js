import { getCurrentUser, logout } from "../../services";
import { removeUserData, setUserData } from "../slices/userSlice";

const getStoredToken = (getState) => {
  if (!getState || typeof getState !== "function") {
    return localStorage.getItem("token");
  }
  return getState()?.user?.token || localStorage.getItem("token");
};

export const getUserThunk = () => async (dispatch, getState) => {
  const token = getStoredToken(getState);
  if (!token) return null;

  try {
    const response = await getCurrentUser(token);
    const user = response?.result || response?.user || {};

    dispatch(
      setUserData({
        name: user.name,
        email: user.email,
        role: user.role,
        token,
      })
    );

    return user;
  } catch (err) {
    console.error("Failed to fetch current user", err);
    return null;
  }
};

export const logoutThunk = () => async (dispatch, getState) => {
  const token = getStoredToken(getState);
  try {
    if (token) {
      await logout(token);
    }
  } catch (err) {
    console.error("Logout failed", err);
  } finally {
    localStorage.removeItem("token");
    dispatch(removeUserData());
  }
};
