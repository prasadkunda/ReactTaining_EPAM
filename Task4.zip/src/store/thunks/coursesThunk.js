import {
  createCourse,
  deleteCourseService,
  getCourses,
  updateCourseService,
} from "../../services";
import {
  deleteCourse,
  saveCourse,
  setCourses,
  updateCourse,
} from "../slices/coursesSlice";

const getStoredToken = (getState) => {
  if (!getState || typeof getState !== "function") {
    return localStorage.getItem("token");
  }
  return getState()?.user?.token || localStorage.getItem("token");
};

export const getCoursesThunk = () => async (dispatch, getState) => {
  try {
    const token = getStoredToken(getState);
    const response = await getCourses(token);
    dispatch(setCourses(response?.result || []));
  } catch (err) {
    console.error("Failed to fetch courses", err);
  }
};

export const deleteCourseThunk = (id) => async (dispatch, getState) => {
  try {
    const token = getStoredToken(getState);
    await deleteCourseService(id, token);
    dispatch(deleteCourse(id));
  } catch (err) {
    console.error("Failed to delete course", err);
  }
};

export const createCourseThunk = (data) => async (dispatch, getState) => {
  try {
    const token = getStoredToken(getState);
    const response = await createCourse(data, token);
    const course = response?.result || response;
    dispatch(saveCourse(course));
    return course;
  } catch (err) {
    console.error("Failed to create course", err);
    throw err;
  }
};

export const updateCourseThunk =
  ({ id, data }) =>
  async (dispatch, getState) => {
    try {
      const token = getStoredToken(getState);
      const updatedData = { ...data, id };
      const response = await updateCourseService(updatedData, token);
      const updatedCourse = response?.result || response;
      dispatch(updateCourse({ id: updatedCourse.id, changes: updatedCourse }));
      return updatedCourse;
    } catch (err) {
      console.error("Failed to update course", err);
      throw err;
    }
  };
