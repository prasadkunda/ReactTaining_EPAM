import { createAuthor, getAuthors } from "../../services";
import { saveAuthor, setAuthors } from "../slices/authorsSlice";

const getStoredToken = (getState) => {
  if (!getState || typeof getState !== "function") {
    return localStorage.getItem("token");
  }
  return getState()?.user?.token || localStorage.getItem("token");
};

export const getAuthorsThunk = () => async (dispatch, getState) => {
  try {
    const token = getStoredToken(getState);
    const response = await getAuthors(token);
    dispatch(setAuthors(response?.result || []));
  } catch (err) {
    console.error("Failed to fetch authors", err);
  }
};

export const createAuthorThunk = (data) => async (dispatch, getState) => {
  try {
    const token = getStoredToken(getState);
    const response = await createAuthor(data, token);
    const author = response?.result || response;
    dispatch(saveAuthor(author));
    return author;
  } catch (err) {
    console.error("Failed to create author", err);
    throw err;
  }
};
