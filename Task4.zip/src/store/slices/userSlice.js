import { createSlice } from "@reduxjs/toolkit";

const initialToken = localStorage.getItem("token") || "";

const initialState = {
  isAuth: initialToken ? true : "",
  name: "",
  email: "",
  token: initialToken,
  role: "",
};

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    setUserData(state, action) {
      const { name, email, token, role } = action.payload || {};
      if (name !== undefined) state.name = name;
      if (email !== undefined) state.email = email;
      if (token !== undefined) state.token = token;
      if (role !== undefined) state.role = role;
      if (token) {
        localStorage.setItem("token", token);
      }
      state.isAuth = Boolean(state.token);
    },

    // Clear user data and de-authenticate
    removeUserData(state) {
      state.name = "";
      state.email = "";
      state.token = null;
      state.role = "";
      state.isAuth = false;

      // Remove persisted token
      localStorage.removeItem("token");
    },
  },
});

export const { setUserData, removeUserData } = userSlice.actions;

export default userSlice.reducer;
