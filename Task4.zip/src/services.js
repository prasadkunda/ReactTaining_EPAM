const API_URL = "http://localhost:4000";

const buildHeaders = (token, includeContentType = true) => {
  const headers = {};
  if (includeContentType) {
    headers["Content-Type"] = "application/json";
  }
  if (token) {
    headers.Authorization = token;
  }
  return headers;
};

export const createUser = async (data) => {
  const response = await fetch(`${API_URL}/register`, {
    method: "POST",
    body: JSON.stringify(data),
    headers: buildHeaders(),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const login = async (data) => {
  const response = await fetch(`${API_URL}/login`, {
    method: "POST",
    body: JSON.stringify(data),
    headers: buildHeaders(),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const getCourses = async (token) => {
  const response = await fetch(`${API_URL}/courses/all`, {
    method: "GET",
    headers: buildHeaders(token),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const getAuthors = async (token) => {
  const response = await fetch(`${API_URL}/authors/all`, {
    method: "GET",
    headers: buildHeaders(token),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const getCurrentUser = async (token) => {
  const response = await fetch(`${API_URL}/users/me`, {
    method: "GET",
    headers: buildHeaders(token),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const updateCourseService = async (updatedData, token) => {
  const response = await fetch(`${API_URL}/courses/${updatedData.id}`, {
    method: "PUT",
    body: JSON.stringify(updatedData),
    headers: buildHeaders(token),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const logout = async (token) => {
  const response = await fetch(`${API_URL}/logout`, {
    method: "DELETE",
    headers: buildHeaders(token),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const deleteCourseService = async (id, token) => {
  const response = await fetch(`${API_URL}/courses/${id}`, {
    method: "DELETE",
    headers: buildHeaders(token),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const createCourse = async (data, token) => {
  const response = await fetch(`${API_URL}/courses/add`, {
    method: "POST",
    body: JSON.stringify(data),
    headers: buildHeaders(token),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};

export const createAuthor = async (data, token) => {
  const response = await fetch(`${API_URL}/authors/add`, {
    method: "POST",
    body: JSON.stringify(data),
    headers: buildHeaders(token),
  });

  if (!response.ok) {
    throw new Error("Network Error");
  }

  return await response.json();
};
