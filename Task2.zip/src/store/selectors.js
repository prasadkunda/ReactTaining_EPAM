// Module 3:
// * create selectors

export const getCoursesSelector = (state) => null;
export const getAuthorsSelector = (state) => null;
export const getUserNameSelector = (state) => null;
export const getUserRoleSelector = (state) => null;
export const getUserTokenSelector = (state) => null;
