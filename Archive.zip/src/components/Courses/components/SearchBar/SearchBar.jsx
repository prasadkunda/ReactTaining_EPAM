import React from "react";

import { Button, Input } from "../../../../common";

import styles from "./styles.module.css";

// SearchBar component for searching courses by title and id
// * includes Input component for search query
// * includes Button component for triggering search
// * performs case-insensitive search
// * searches by occurrence of characters in the string, not just beginning
export const SearchBar = ({ onSearch, onClear }) => {
  const [searchQuery, setSearchQuery] = React.useState("");

  const handleInputChange = (event) => {
    const value = event.target.value;
    setSearchQuery(value);

    // If search field is empty, display all courses
    if (value.trim() === "") {
      onClear();
    }
  };

  const handleSearch = () => {
    onSearch(searchQuery);
  };

  return (
    <div className={styles.searchBarContainer}>
      <Input
        placeholderText="Search by title or id..."
        labelText="Search Courses"
        onChange={handleInputChange}
        value={searchQuery}
        data-testid="searchInput"
      />
      <Button
        buttonText="SEARCH"
        handleClick={handleSearch}
        data-testid="searchButton"
      />
    </div>
  );
};
