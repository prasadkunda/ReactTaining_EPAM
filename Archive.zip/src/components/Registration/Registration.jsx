// Module 1. You don't need to do anything with this component (we had to comment this component for 1st module tests)

// Module 2.
// * uncomment this component (ctrl + a => ctrl + /)
// * finish markup according to the figma https://www.figma.com/file/m0N0SGLclqUEGR6TUNvyn9/Fundamentals-Courses?type=design&node-id=2932-219&mode=design&t=0FIG0iRzKcD0s16M-0
// * add validation for fields: all fields are required. Show validation message. https://www.figma.com/file/m0N0SGLclqUEGR6TUNvyn9/Fundamentals-Courses?type=design&node-id=2932-257&mode=design&t=0FIG0iRzKcD0s16M-0
// * render this component by route '/registration'
// * submit form data and make POST API request '/registration'.
// * after successful registration navigates to '/login' route.
// * component should have a link to the Login page (see design)
// ** TASK DESCRIPTION ** - https://ebook.learn.epam.com/react-fundamentals/docs/module-2/home-task/components#registration-new-component

import React from "react";

import styles from "./styles.module.css";
import { Link, useNavigate } from "react-router-dom";
import { Button, Input } from "../../common";
import * as services from "../../services"; // ⚠️ CHANGED

export const Registration = () => {
  const [formData, setFormData] = React.useState({
    name: "",
    email: "",
    password: "",
  });
  const [errors, setErrors] = React.useState({});
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { name, email, password } = formData;

    const newErrors = {};
    if (!name || name.trim() === "") newErrors.name = "Name is required";
    if (!email || email.trim() === "") newErrors.email = "Email is required";
    if (!password || password.trim() === "")
      newErrors.password = "Password is required";

    if (Object.keys(newErrors).length) {
      setErrors(newErrors);
      return;
    }

    try {
      await services.createUser({ name, email, password }); // ⚠️ CHANGED
      navigate("/login");
    } catch (err) {
      // optionally surface API error state here
      // setErrors(prev => ({ ...prev, api: 'Registration failed' }));
      // console.error("Registration error:", err);
    }
  };

  const onChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  return (
    <div className={styles.container}>
      <h1>Registration</h1>
      <div className={styles.formContainer}>
        <form onSubmit={handleSubmit}>
          <Input
            placeholderText="Input text"
            labelText="Name"
            name="name"
            onChange={onChange}
            value={formData.name}
            dataTestId="name-input"
          />
          {errors.name && <div className={styles.error}>{errors.name}</div>}

          <Input
            placeholderText="Input text"
            labelText="Email"
            name="email"
            onChange={onChange}
            value={formData.email}
            dataTestId="email-input"
          />
          {errors.email && <div className={styles.error}>{errors.email}</div>}

          <Input
            placeholderText="Input text"
            labelText="Password"
            name="password"
            onChange={onChange}
            value={formData.password}
            type="password"
            dataTestId="password-input"
          />
          {errors.password && (
            <div className={styles.error}>{errors.password}</div>
          )}

          <Button
            type="submit"
            buttonText="Register"
            data-testid="registration-button"
          />
        </form>

        <p>
          If you have an account you may&nbsp;<Link to="/login">Login</Link>
        </p>
      </div>
    </div>
  );
};
export default Registration;
