import React, { useState, useEffect } from "react";

import styles from "./styles.module.css";
import { Button } from "../../common";
import { CourseCard, SearchBar } from "./components";
import { Link, useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";

// Module 1:
// * render list of components using 'CourseCard' component for each course
// * render 'ADD NEW COURSE' button (reuse Button component)
// ** TASK DESCRIPTION ** - https://ebook.learn.epam.com/react-fundamentals/docs/module-1/home-task/components#courses-component
// * render EmptyCourseList component when no courses
// ** TASK DESCRIPTION ** - https://ebook.learn.epam.com/react-fundamentals/docs/module-1/home-task/components#emptycourselist-component
// * DO NOT map authors to the course inside Courses.jsx component (DO it inside CourseCard)

// Module 2:
// * render this component by route '/courses'
// * navigate to this component if 'localStorage' contains user's token
// * navigate to the route courses/add by clicking 'Add New Course' button, use 'Link' component from 'react-router-dom'
// ** TASK DESCRIPTION ** - https://ebook.learn.epam.com/react-fundamentals/docs/module-2/home-task/components#courses

// Module 3:
// * stop using mocked courses and authors data
// * delete props 'coursesList' and 'authorsList'
// * use useSelector to get courses and authors from the store
// ** TASK DESCRIPTION ** - https://ebook.learn.epam.com/react-fundamentals/docs/module-3/home-task/components#courses-component

// Module 4:
// navigate to '/courses/add' route by clicking 'ADD NEW COURSE' button in the 'EmptyCourseList'.
// show message 'You don't have permissions to create a course. Please log in as ADMIN' by clicking ADD NEW COURSE button in the 'EmptyCourseList'.
// ** TASK DESCRIPTION ** - https://ebook.learn.epam.com/react-fundamentals/docs/module-4/home-task/components#emptycourselist-component

// Module 5:
// * proposed cases for unit tests:
//   ** Courses should display amount of CourseCard equal length of courses array.
//   ** CourseForm should be shown after a click on the "Add new course" button.

export const Courses = ({ handleShowCourse }) => {
  const coursesList = useSelector((state) => state.courses);
  const authorsList = useSelector((state) => state.authors);
  const navigate = useNavigate();
  const [filteredCourses, setFilteredCourses] = useState(coursesList);
  const courses = coursesList;
  useEffect(() => {
    if (coursesList) {
      setFilteredCourses(coursesList);
    }
  }, [coursesList]);

  useEffect(() => {
    console.log(coursesList, authorsList, "At course component useeffect");
  }, [coursesList, authorsList]);

  const hasCourses =
    Array.isArray(filteredCourses) && filteredCourses.length > 0;

  const handleCourseSelect = (courseId) => {
    if (courseId) {
      navigate(`/courses/${courseId}`);
    }
  };

  const handleSearch = (searchQuery) => {
    const query = searchQuery.toLowerCase().trim();

    if (query === "") {
      setFilteredCourses(courses);
      return;
    }

    const results = courses.filter((course) => {
      const titleMatch = course.title.toLowerCase().includes(query);
      const idMatch = course.id.toLowerCase().includes(query);
      return titleMatch || idMatch;
    });

    setFilteredCourses(results);
  };

  const handleClearSearch = () => {
    setFilteredCourses(courses);
  };

  return (
    <>
      {hasCourses || courses.length > 0 ? (
        <div className={styles.coursesContainer}>
          <div className={styles.panel}>
            <Link to="/courses/add">
              <Button
                buttonText="ADD NEW COURSE"
                data-testid="addCourse"
              ></Button>
            </Link>
          </div>
          <SearchBar onSearch={handleSearch} onClear={handleClearSearch} />
          {hasCourses ? (
            filteredCourses.map((course) => (
              <CourseCard
                key={course?.id}
                course={course}
                authorsList={authorsList}
                handleShowCourse={() => handleCourseSelect(course.id)}
              />
            ))
          ) : (
            <div
              className={styles.noSearchResults}
              data-testid="noSearchResults"
            >
              <p>No courses found matching your search.</p>
            </div>
          )}
        </div>
      ) : (
        <div className={styles.emptyContainer} data-testid="emptyContainer">
          <h2>Your List Is Empty</h2>
          <p>Please use "Add New Course" button to add your first course</p>
          <Link to="/courses/add">
            <Button buttonText="ADD NEW COURSE" data-testid="addCourse" />
          </Link>
        </div>
      )}
    </>
  );
};
