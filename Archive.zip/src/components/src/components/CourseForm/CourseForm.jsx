import React from "react";
import { Link, useNavigate } from "react-router-dom";

import styles from "./styles.module.css";
import { Button, Input } from "../../common";
import { AuthorItem, CreateAuthor } from "./components";
import { getCourseDuration } from "../../helpers";

import { useDispatch } from "react-redux";
import { saveAuthor } from "../../store/slices/authorsSlice";
import { saveCourse } from "../../store/slices/coursesSlice";

export const CourseForm = ({
  authorsList = [],
  // createCourse,
  // createAuthor,
}) => {
  const navigate = useNavigate();
  const dispatch = useDispatch();

  const [title, setTitle] = React.useState("");
  const [description, setDescription] = React.useState("");
  const [duration, setDuration] = React.useState(0);
  const [courseAuthors, setCourseAuthors] = React.useState([]);
  const [availableAuthors, setAvailableAuthors] = React.useState(
    ...authorsList
  );

  const onChangeTitle = (e) => setTitle(e.target.value);
  const onChangeDescription = (e) => setDescription(e.target.value);
  const onChangeDuration = (e) => setDuration(Number(e.target.value || 0));

  const deleteAuthorItem = (author) => {
    console.log(courseAuthors, "course author", author);
    setCourseAuthors([...courseAuthors, author]);
    setAvailableAuthors(availableAuthors.filter((a) => a.id !== author.id));
  };

  const handleDeleteAuthor = (author) => {
    setCourseAuthors(courseAuthors.filter((a) => a.id !== author.id));
    setAvailableAuthors([...availableAuthors, author]);
  };

  const handleCreateAuthor = (author) => {
    console.log(author, "create author.....", availableAuthors);
    setAvailableAuthors([...availableAuthors, author]);
    dispatch(saveAuthor(author));
  };

  const isFormValid = () => {
    return title.length >= 2 && description.length >= 2 && duration > 0;
  };

  const onSubmit = (e) => {
    e.preventDefault();
    if (isFormValid()) {
      const date = new Date().toLocaleDateString("en-GB"); // current date
      // const formattedDate = `${
      //   date.getMonth() + 1
      // }/${date.getDate()}/${date.getFullYear()}`;
      console.log(availableAuthors, "availableAuthors...");
      const courseData = {
        title,
        description,
        duration,
        authors: courseAuthors.map((c) => c.id),
        creationDate: date,
        id: Date.now().toString(36) + Math.random().toString(36),
      };
      //  if (createCourse) {
      //  createCourse(courseData);
      dispatch(saveCourse(courseData));
      navigate("/courses");
      //} else {
      // setTitle("");
      // setDescription("");
      // setDuration(0);
      // setCourseAuthors([]);
      // }
    }
  };

  return (
    <div className={styles.container}>
      <h2>Course Edit or Create Page</h2>

      <form onSubmit={onSubmit}>
        <Input
          label="Title"
          data-testid="titleInput"
          placeholderText="Enter title"
          onChange={onChangeTitle}
          value={title}
          name="title"
        />
        <label>
          Description
          <textarea
            className={styles.description}
            data-testid="descriptionTextArea"
            value={description}
            onChange={onChangeDescription}
          />
        </label>
        <div className={styles.infoWrapper}>
          <div>
            <div className={styles.duration}>
              <Input
                labelText="Duration"
                data-testid="durationInput"
                placeholderText="Input text"
                value={duration}
                onChange={onChangeDuration}
                name="duration"
                type="number"
              />
              <p>{getCourseDuration(duration)}</p>
            </div>
            <h2>Authors</h2>
            <div className={styles.authorsSection}>
              <CreateAuthor onCreateAuthor={handleCreateAuthor} />
            </div>

            <div className={styles.authorsContainer}>
              <h3>Authors List</h3>
              {availableAuthors && availableAuthors.length > 0 ? (
                availableAuthors.map((author) => (
                  // <React.Fragment key={a.id}>
                  //   <div className={styles.authorItem} data-testid="authorItem">
                  //     <span>{a.name}</span>
                  //     <button
                  //       data-testid="addAuthor"
                  //       type="button"
                  //       onClick={() => handleAddAuthor(a)}
                  //     >
                  //       <img src={deleteIcon} alt="Delete" />;
                  //     </button>
                  //   </div>
                  // </React.Fragment>

                  <AuthorItem
                    key={author.id}
                    author={author}
                    deleteAuthorItem={deleteAuthorItem}
                  />
                ))
              ) : (
                <p className={styles.notification}>Authors list is empty</p>
              )}
            </div>
          </div>

          <div className={styles.courseAuthorsContainer}>
            <h2>Course authors</h2>
            {courseAuthors && courseAuthors.length > 0 ? (
              courseAuthors.map((courseAuthor) => (
                // <React.Fragment key={a.id}>
                //   <div className={styles.authorItem}>
                //     <span>{a.name}</span>
                //     <button
                //       type="button"
                //       data-testid="addInCourseAuthor"
                //       onClick={() => handleDeleteAuthor(a)}
                //     >
                //       delete author
                //     </button>
                //   </div>
                // </React.Fragment>

                <AuthorItem
                  key={courseAuthor.id}
                  author={courseAuthor}
                  deleteAuthorItem={handleDeleteAuthor}
                />
              ))
            ) : (
              <p className={styles.notification}>Course Author </p>
            )}
          </div>
        </div>

        <div className={styles.buttonsContainer}>
          <Button
            buttonText="CREATE COURSE"
            type="submit"
            disabled={!isFormValid()}
            data-testid="createCourseButton"
            handleClick={onSubmit}
          ></Button>

          <Link to="/courses">
            <Button buttonText="CANCEL" />
          </Link>
        </div>
      </form>
    </div>
  );
};
