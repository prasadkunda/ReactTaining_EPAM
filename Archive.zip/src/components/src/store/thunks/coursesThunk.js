import { createAsyncThunk } from "@reduxjs/toolkit";
import { getCourses } from "../../services";

// export const updateCourseThunk = () => {};

// export const deleteCourseThunk = () => {};

// export const createCourseThunk = () => {};

export const getCoursesThunk = createAsyncThunk(
  "courses/fetchCourses",
  async () => {
    const response = await getCourses();
    return response.result;
  }
);
