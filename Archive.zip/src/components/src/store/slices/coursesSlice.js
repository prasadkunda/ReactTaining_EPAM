import { createSlice } from "@reduxjs/toolkit";
import { getCoursesThunk } from "../thunks/coursesThunk";

const initialState = []; // array of course objects

export const coursesSlice = createSlice({
  name: "courses",
  initialState,
  reducers: {
    // Replace the entire list of courses
    setCourses(state, action) {
      // action.payload: Course[]
      return action.payload;
    },

    // Add a new course
    saveCourse(state, action) {
      // action.payload: Course
      state.push(action.payload);
    },

    // Delete a course by id
    deleteCourse(state, action) {
      // action.payload: string | number (course id)
      const id = action.payload;
      return state.filter((course) => course.id !== id);
    },

    // Update an existing course by id
    updateCourse(state, action) {
      // action.payload: { id: string|number, changes: Partial<Course> }
      const { id, changes } = action.payload;
      const idx = state.findIndex((c) => c.id === id);
      if (idx !== -1) {
        state[idx] = { ...state[idx], ...changes };
      }
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getCoursesThunk.fulfilled, (state, action) => {
        return action.payload;
      })
      .addCase(getCoursesThunk.pending, (state) => {
        // handle loading state
      })
      .addCase(getCoursesThunk.rejected, (state, action) => {
        // handle error
      });
  },
});

// use these actions in your components / thunks
export const { setCourses, saveCourse, deleteCourse, updateCourse } =
  coursesSlice.actions;

export default coursesSlice.reducer;
